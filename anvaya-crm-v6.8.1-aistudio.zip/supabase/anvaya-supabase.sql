-- ============================================================================
-- ANVAYA CRM — Supabase database
--
-- One file. Paste it into Supabase → SQL Editor → Run.
--
-- What it creates:
--   • 51 tables — organisations, people, sales, money, support, projects,
--     automation, documents, payments, audit
--   • 182 row-level-security policies — a row is visible only to its own
--     organisation, and writes additionally require a permission key
--   • helper functions that resolve the caller from either the Express
--     backend's session context or a Supabase Auth JWT
--   • a seed: one workspace, nine roles, a six-stage pipeline, numbering
--
-- HOW TO RUN
--   1. Run this file. The tables and policies are created; the seed notices
--      there is no user yet and skips.
--   2. Create your account (Authentication → Users), or register through the app.
--   3. Run this file again. The seed creates the workspace for that account.
--   Both runs are safe to repeat — nothing is duplicated.
--
-- OPTIONAL: 04_optional_supabase_auth.sql, only if the browser talks to
-- Supabase directly with no backend in between.
-- ============================================================================

-- ============================================================================
-- 00_helpers.sql
-- ============================================================================

-- pgcrypto is present on Supabase. gen_random_uuid() is built into PostgreSQL 13+,
-- so the extension is a belt-and-braces line for older instances.
do $$ begin
  create extension if not exists pgcrypto;
exception when others then
  raise notice 'pgcrypto unavailable — gen_random_uuid() is built in, continuing';
end $$;

create schema if not exists app;

-- The helpers below read from `members`, which 01_schema.sql creates. Turning
-- body checking off lets this file run first; the bodies are exercised the
-- moment a policy touches a table.
set check_function_bodies = off;

-- ---------------------------------------------------------------- identity --
-- Two ways to identify the caller, in priority order:
--   1. app.user_id — set by the Express backend for each transaction
--      (select set_config('app.user_id', '<uuid>', true))
--   2. auth.uid()  — the Supabase Auth JWT, when the app talks to Supabase
--      directly from the browser.
-- Supporting both means the same policies serve both deployment shapes.

create or replace function app.uid() returns uuid
  language sql stable security definer set search_path = public, auth as $$
    select coalesce(
      nullif(current_setting('app.user_id', true), '')::uuid,
      auth.uid()
    )
$$;

-- The organisation in play: an explicit setting first (backend), then a JWT
-- claim, then the caller's first active membership.
create or replace function app.current_org() returns uuid
  language sql stable security definer set search_path = public, auth as $$
    select coalesce(
      nullif(current_setting('app.org_id', true), '')::uuid,
      nullif(current_setting('request.jwt.claim.org_id', true), '')::uuid,
      (select m.org_id
         from members m
        where m.user_id = app.uid() and m.status = 'active'
        order by m.created_at
        limit 1)
    )
$$;

create or replace function app.current_user() returns uuid
  language sql stable security definer set search_path = public, auth as $$
    select app.uid()
$$;

-- Permissions come from the caller's role row, not from a session variable.
-- A backend that sets app.perms still wins, so nothing breaks in that mode.
create or replace function app.perms() returns text[]
  language sql stable security definer set search_path = public, auth as $$
    select coalesce(
      string_to_array(nullif(current_setting('app.perms', true), ''), ','),
      (select r.permissions
         from members m
         join roles r on r.id = m.role_id
        where m.user_id = app.uid()
          and m.org_id = app.current_org()
          and m.status = 'active'
        limit 1),
      '{}'::text[]
    )
$$;

create or replace function app.has_perm(p text) returns boolean
  language sql stable security definer set search_path = public, auth as $$
    select coalesce(p = any(app.perms()) or '*' = any(app.perms()), false)
$$;

create or replace function app.is_member() returns boolean
  language sql stable security definer set search_path = public, auth as $$
    select exists (
      select 1 from members m
       where m.user_id = app.uid()
         and m.org_id = app.current_org()
         and m.status = 'active'
    )
$$;

create or replace function app.touch() returns trigger
  language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end $$;

-- ---------------------------------------------------------------- grants ----
grant usage on schema app to authenticated, anon, service_role;
grant execute on all functions in schema app to authenticated, anon, service_role;
grant usage on schema public to authenticated, anon, service_role;
grant select, insert, update, delete on all tables in schema public to authenticated;
alter default privileges in schema public grant select, insert, update, delete on tables to authenticated;

reset check_function_bodies;

-- ============================================================================
-- 01_schema.sql
-- ============================================================================

create table if not exists organisations (
  id            uuid primary key default gen_random_uuid(),
  name          text not null,
  slug          text not null unique,
  industry      text,
  currency      char(3) not null default 'INR',
  timezone      text not null default 'Asia/Kolkata',
  locale        text not null default 'en-IN',
  fiscal_start_month int not null default 4 check (fiscal_start_month between 1 and 12),
  working_hours jsonb not null default '{"days":[1,2,3,4,5,6],"start":"09:30","end":"18:30"}',
  logo_url      text,
  plan          text not null default 'professional',
  status        text not null default 'active' check (status in ('active','suspended','deleted')),
  settings      jsonb not null default '{}',
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  deleted_at    timestamptz
);

create table if not exists workspaces (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null references organisations(id) on delete cascade,
  name       text not null,
  slug       text not null,
  is_default boolean not null default false,
  settings   jsonb not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (org_id, slug)
);

create table if not exists users (
  id                uuid primary key default gen_random_uuid(),
  email             text not null unique,
  password_hash     text not null,
  full_name         text not null,
  phone             text,
  avatar_initials   text,
  email_verified_at timestamptz,
  mfa_secret        text,
  is_platform_admin boolean not null default false,
  last_login_at     timestamptz,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);

create table if not exists roles (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  key         text not null,
  name        text not null,
  description text,
  permissions text[] not null default '{}',
  is_system   boolean not null default false,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  unique (org_id, key)
);

create table if not exists members (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  user_id     uuid not null references users(id) on delete cascade,
  role_id     uuid not null references roles(id),
  workspace_id uuid references workspaces(id) on delete set null,
  status      text not null default 'active' check (status in ('invited','active','suspended')),
  title       text,
  department  text,
  invited_by  uuid references users(id),
  invited_at  timestamptz,
  joined_at   timestamptz,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  unique (org_id, user_id)
);

create table if not exists sessions (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references users(id) on delete cascade,
  token_hash text not null unique,
  ip         text,
  user_agent text,
  expires_at timestamptz not null,
  revoked_at timestamptz,
  created_at timestamptz not null default now()
);

-- ------------------------------------------------------------------- CRM ---
create table if not exists companies (
  id             uuid primary key default gen_random_uuid(),
  org_id         uuid not null references organisations(id) on delete cascade,
  name           text not null,
  domain         text,
  industry       text,
  size_band      text,
  annual_revenue numeric(16,2),
  phone          text,
  website        text,
  city           text,
  country        text default 'India',
  address        jsonb not null default '{}',
  parent_id      uuid references companies(id) on delete set null,
  owner_id       uuid references members(id) on delete set null,
  health_score   int not null default 60 check (health_score between 0 and 100),
  tags           text[] not null default '{}',
  custom         jsonb not null default '{}',
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  deleted_at     timestamptz
);

create table if not exists contacts (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null references organisations(id) on delete cascade,
  company_id   uuid references companies(id) on delete set null,
  first_name   text not null,
  last_name    text,
  email        text,
  phone        text,
  title        text,
  city         text,
  owner_id     uuid references members(id) on delete set null,
  tags         text[] not null default '{}',
  consent      jsonb not null default '{"email":true,"whatsapp":false,"calls":true,"recorded_at":null}',
  health_score int not null default 60 check (health_score between 0 and 100),
  custom       jsonb not null default '{}',
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  deleted_at   timestamptz
);
create index if not exists contacts_org_company on contacts (org_id, company_id);
create index if not exists contacts_email on contacts (org_id, lower(email));

create table if not exists leads (
  id                  uuid primary key default gen_random_uuid(),
  org_id              uuid not null references organisations(id) on delete cascade,
  name                text not null,
  company_name        text,
  email               text,
  phone               text,
  source              text not null default 'website',
  status              text not null default 'new'
                      check (status in ('new','contacted','qualified','proposal','negotiation','converted','lost')),
  score               int check (score between 0 and 100),
  score_reason        text,
  owner_id            uuid references members(id) on delete set null,
  estimated_value     numeric(16,2) not null default 0,
  currency            char(3) not null default 'INR',
  notes               text,
  converted_contact_id uuid references contacts(id) on delete set null,
  converted_deal_id   uuid,
  lost_reason         text,
  last_contacted_at   timestamptz,
  custom              jsonb not null default '{}',
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),
  deleted_at          timestamptz
);
create index if not exists leads_org_status on leads (org_id, status);

create table if not exists pipelines (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null references organisations(id) on delete cascade,
  name       text not null,
  is_default boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists stages (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  pipeline_id uuid not null references pipelines(id) on delete cascade,
  name        text not null,
  position    int not null default 0,
  probability int not null default 10 check (probability between 0 and 100),
  is_won      boolean not null default false,
  is_lost     boolean not null default false,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table if not exists deals (
  id                  uuid primary key default gen_random_uuid(),
  org_id              uuid not null references organisations(id) on delete cascade,
  pipeline_id         uuid not null references pipelines(id),
  stage_id            uuid not null references stages(id),
  company_id          uuid references companies(id) on delete set null,
  contact_id          uuid references contacts(id) on delete set null,
  title               text not null,
  value               numeric(16,2) not null default 0,
  currency            char(3) not null default 'INR',
  probability         int check (probability between 0 and 100),
  expected_close_date date,
  owner_id            uuid references members(id) on delete set null,
  status              text not null default 'open' check (status in ('open','won','lost')),
  lost_reason         text,
  competitor          text,
  source_lead_id      uuid references leads(id) on delete set null,
  stage_changed_at    timestamptz not null default now(),
  custom              jsonb not null default '{}',
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),
  deleted_at          timestamptz
);
create index if not exists deals_org_status on deals (org_id, status);
create index if not exists deals_org_stage on deals (org_id, stage_id);

create table if not exists activities (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  type        text not null check (type in ('call','email','meeting','note','visit')),
  subject     text not null,
  body        text,
  contact_id  uuid references contacts(id) on delete cascade,
  company_id  uuid references companies(id) on delete cascade,
  deal_id     uuid references deals(id) on delete cascade,
  ticket_id   uuid,
  owner_id    uuid references members(id) on delete set null,
  occurred_at timestamptz not null default now(),
  duration_min int,
  created_by  uuid references users(id),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists activities_org_contact on activities (org_id, contact_id, occurred_at desc);

create table if not exists tasks (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null references organisations(id) on delete cascade,
  title        text not null,
  notes        text,
  due_date     date,
  due_time     time,
  priority     text not null default 'medium' check (priority in ('low','medium','high','urgent')),
  status       text not null default 'open' check (status in ('open','in_progress','done','cancelled')),
  assignee_id  uuid references members(id) on delete set null,
  related_type text,
  related_id   uuid,
  recurrence   text,
  completed_at timestamptz,
  created_by   uuid references users(id),
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index if not exists tasks_org_assignee on tasks (org_id, assignee_id, status);

-- ------------------------------------------------------------- service ------
create table if not exists tickets (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references organisations(id) on delete cascade,
  number        text not null,
  subject       text not null,
  description   text,
  contact_id    uuid references contacts(id) on delete set null,
  company_id    uuid references companies(id) on delete set null,
  deal_id       uuid references deals(id) on delete set null,
  priority      text not null default 'medium' check (priority in ('low','medium','high','critical')),
  status        text not null default 'open' check (status in ('open','in_progress','waiting','resolved','closed')),
  category      text,
  assignee_id   uuid references members(id) on delete set null,
  sla_policy    text not null default 'standard',
  sla_due_at    timestamptz,
  first_response_at timestamptz,
  resolved_at   timestamptz,
  csat          int check (csat between 1 and 5),
  created_by    uuid references users(id),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (org_id, number)
);
create index if not exists tickets_org_status on tickets (org_id, status);

create table if not exists ticket_comments (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null references organisations(id) on delete cascade,
  ticket_id  uuid not null references tickets(id) on delete cascade,
  author_id  uuid references users(id),
  body       text not null,
  is_internal boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists knowledge_articles (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null references organisations(id) on delete cascade,
  title      text not null,
  body       text not null,
  category   text,
  is_public  boolean not null default false,
  created_by uuid references users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ------------------------------------------------------------ marketing ----
create table if not exists campaigns (
  id             uuid primary key default gen_random_uuid(),
  org_id         uuid not null references organisations(id) on delete cascade,
  name           text not null,
  channel        text not null default 'email' check (channel in ('email','sms','whatsapp')),
  status         text not null default 'draft' check (status in ('draft','scheduled','sending','sent','paused','failed')),
  subject        text,
  body           text,
  audience       jsonb not null default '{}',
  scheduled_at   timestamptz,
  sent_at        timestamptz,
  provider       text,
  provider_ref   text,
  stats          jsonb not null default '{"sent":0,"delivered":0,"opened":0,"clicked":0,"bounced":0}',
  created_by     uuid references users(id),
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);

create table if not exists campaign_recipients (
  id                  uuid primary key default gen_random_uuid(),
  org_id              uuid not null references organisations(id) on delete cascade,
  campaign_id         uuid not null references campaigns(id) on delete cascade,
  contact_id          uuid references contacts(id) on delete cascade,
  status              text not null default 'queued' check (status in ('queued','sent','delivered','opened','clicked','bounced','failed')),
  provider_message_id text,
  error               text,
  updated_at          timestamptz not null default now(),
  created_at          timestamptz not null default now()
);

-- ------------------------------------------------------------- commerce ----
create table if not exists products (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references organisations(id) on delete cascade,
  sku           text not null,
  name          text not null,
  category      text,
  description   text,
  unit_price    numeric(14,2) not null default 0,
  tax_rate      numeric(5,2) not null default 18,
  stock_qty     numeric(14,2) not null default 0,
  reorder_point numeric(14,2) not null default 0,
  uom           text default 'unit',
  is_active     boolean not null default true,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (org_id, sku)
);

create table if not exists quotations (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references organisations(id) on delete cascade,
  number        text not null,
  deal_id       uuid references deals(id) on delete set null,
  contact_id    uuid references contacts(id) on delete set null,
  company_id    uuid references companies(id) on delete set null,
  status        text not null default 'draft' check (status in ('draft','sent','accepted','rejected','expired')),
  issue_date    date not null default current_date,
  valid_until   date,
  currency      char(3) not null default 'INR',
  subtotal      numeric(16,2) not null default 0,
  discount_total numeric(16,2) not null default 0,
  tax_total     numeric(16,2) not null default 0,
  total         numeric(16,2) not null default 0,
  notes         text,
  terms         text,
  version       int not null default 1,
  approved_at   timestamptz,
  created_by    uuid references users(id),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (org_id, number)
);

create table if not exists quotation_items (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  quotation_id uuid not null references quotations(id) on delete cascade,
  product_id  uuid references products(id) on delete set null,
  description text not null,
  qty         numeric(14,2) not null default 1,
  unit_price  numeric(14,2) not null default 0,
  discount    numeric(14,2) not null default 0,
  tax_rate    numeric(5,2) not null default 18,
  line_total  numeric(16,2) not null default 0,
  position    int not null default 0
);

create table if not exists invoices (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references organisations(id) on delete cascade,
  number        text not null,
  quotation_id  uuid references quotations(id) on delete set null,
  deal_id       uuid references deals(id) on delete set null,
  contact_id    uuid references contacts(id) on delete set null,
  company_id    uuid references companies(id) on delete set null,
  status        text not null default 'draft' check (status in ('draft','sent','partially_paid','paid','overdue','cancelled')),
  issue_date    date not null default current_date,
  due_date      date,
  currency      char(3) not null default 'INR',
  subtotal      numeric(16,2) not null default 0,
  tax_total     numeric(16,2) not null default 0,
  total         numeric(16,2) not null default 0,
  amount_paid   numeric(16,2) not null default 0,
  notes         text,
  paid_at       timestamptz,
  created_by    uuid references users(id),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (org_id, number)
);

create table if not exists invoice_items (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  invoice_id  uuid not null references invoices(id) on delete cascade,
  description text not null,
  qty         numeric(14,2) not null default 1,
  unit_price  numeric(14,2) not null default 0,
  tax_rate    numeric(5,2) not null default 18,
  line_total  numeric(16,2) not null default 0,
  position    int not null default 0
);

create table if not exists payments (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null references organisations(id) on delete cascade,
  invoice_id   uuid not null references invoices(id) on delete cascade,
  amount       numeric(16,2) not null,
  method       text not null default 'bank_transfer',
  provider     text,
  provider_ref text,
  status       text not null default 'succeeded' check (status in ('pending','succeeded','failed','refunded')),
  received_at  timestamptz not null default now(),
  created_at   timestamptz not null default now()
);

-- ------------------------------------------------------------- delivery ----
create table if not exists projects (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  name        text not null,
  deal_id     uuid references deals(id) on delete set null,
  company_id  uuid references companies(id) on delete set null,
  status      text not null default 'planned' check (status in ('planned','active','on_hold','completed','cancelled')),
  start_date  date,
  end_date    date,
  budget      numeric(16,2) not null default 0,
  spent       numeric(16,2) not null default 0,
  progress    int not null default 0 check (progress between 0 and 100),
  manager_id  uuid references members(id) on delete set null,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table if not exists milestones (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  project_id  uuid not null references projects(id) on delete cascade,
  name        text not null,
  due_date    date,
  completed_at timestamptz,
  position    int not null default 0
);

-- ----------------------------------------------------------- automation ----
create table if not exists workflows (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  name        text not null,
  description text,
  status      text not null default 'draft' check (status in ('draft','active','paused')),
  version     int not null default 1,
  trigger     jsonb not null,
  conditions  jsonb not null default '[]',
  actions     jsonb not null default '[]',
  run_count   int not null default 0,
  last_run_at timestamptz,
  created_by  uuid references users(id),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table if not exists workflow_runs (
  id             uuid primary key default gen_random_uuid(),
  org_id         uuid not null references organisations(id) on delete cascade,
  workflow_id    uuid not null references workflows(id) on delete cascade,
  workflow_version int not null default 1,
  trigger_entity text,
  trigger_id     uuid,
  status         text not null default 'running' check (status in ('running','succeeded','failed','skipped','awaiting_approval')),
  context        jsonb not null default '{}',
  error          text,
  started_at     timestamptz not null default now(),
  finished_at    timestamptz
);

create table if not exists workflow_steps (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null references organisations(id) on delete cascade,
  run_id     uuid not null references workflow_runs(id) on delete cascade,
  step_index int not null default 0,
  node_type  text not null,
  status     text not null default 'succeeded',
  output     jsonb not null default '{}',
  error      text,
  created_at timestamptz not null default now()
);

-- ------------------------------------------------------------------- AI ----
create table if not exists ai_runs (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  user_id     uuid references users(id),
  agent       text not null default 'copilot',
  provider    text,
  model       text,
  prompt      text,
  response    text,
  status      text not null default 'succeeded' check (status in ('running','succeeded','failed')),
  tokens_in   int not null default 0,
  tokens_out  int not null default 0,
  latency_ms  int,
  error       text,
  created_at  timestamptz not null default now()
);

create table if not exists ai_actions (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null references organisations(id) on delete cascade,
  run_id       uuid references ai_runs(id) on delete cascade,
  action       text not null,
  target_table text,
  target_id    uuid,
  payload      jsonb not null default '{}',
  status       text not null default 'proposed' check (status in ('proposed','approved','rejected','applied','failed')),
  approved_by  uuid references users(id),
  applied_at   timestamptz,
  created_at   timestamptz not null default now()
);

-- ------------------------------------------------------------- platform ----
create table if not exists custom_fields (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null references organisations(id) on delete cascade,
  entity     text not null check (entity in ('lead','contact','company','deal','ticket','project')),
  key        text not null,
  label      text not null,
  type       text not null default 'text' check (type in ('text','number','date','select','multiselect','boolean','url')),
  options    jsonb not null default '[]',
  required   boolean not null default false,
  position   int not null default 0,
  created_at timestamptz not null default now(),
  unique (org_id, entity, key)
);

create table if not exists custom_values (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null references organisations(id) on delete cascade,
  field_id   uuid not null references custom_fields(id) on delete cascade,
  record_id  uuid not null,
  value      text,
  updated_at timestamptz not null default now(),
  unique (field_id, record_id)
);

create table if not exists notifications (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null references organisations(id) on delete cascade,
  user_id    uuid not null references users(id) on delete cascade,
  type       text not null default 'info',
  title      text not null,
  body       text,
  link       text,
  read_at    timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists audit_logs (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null references organisations(id) on delete cascade,
  actor_id   uuid references users(id),
  actor_name text,
  action     text not null,
  entity     text,
  entity_id  uuid,
  before     jsonb,
  after      jsonb,
  ip         text,
  created_at timestamptz not null default now()
);
create index if not exists audit_org_created on audit_logs (org_id, created_at desc);

create table if not exists subscriptions (
  id                 uuid primary key default gen_random_uuid(),
  org_id             uuid not null references organisations(id) on delete cascade,
  plan               text not null default 'professional',
  status             text not null default 'trialing' check (status in ('trialing','active','past_due','cancelled')),
  seats              int not null default 5,
  trial_ends_at      timestamptz,
  current_period_end timestamptz,
  usage              jsonb not null default '{"ai_credits":0,"emails":0}',
  limits             jsonb not null default '{"seats":5,"ai_credits":2000,"emails":5000}',
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now()
);

create table if not exists integrations (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null references organisations(id) on delete cascade,
  provider     text not null,
  status       text not null default 'disconnected' check (status in ('disconnected','pending','connected','error')),
  scopes       text[] not null default '{}',
  config       jsonb not null default '{}',
  connected_at timestamptz,
  last_error   text,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  unique (org_id, provider)
);

-- forward reference: leads -> deals (deals is created after leads)
alter table leads drop constraint if exists leads_converted_deal_fk;
alter table leads add constraint leads_converted_deal_fk
  foreign key (converted_deal_id) references deals(id) on delete set null;

-- updated_at triggers
do $$
declare t text;
begin
  foreach t in array array[
    'organisations','workspaces','users','roles','members','companies','contacts','leads',
    'pipelines','stages','deals','activities','tasks','tickets','knowledge_articles',
    'campaigns','products','quotations','invoices','projects','workflows','custom_fields',
    'subscriptions','integrations'
  ]
  loop
    execute format('drop trigger if exists touch_%1$s on %1$I', t);
    execute format('create trigger touch_%1$s before update on %1$I for each row execute function app.touch()', t);
  end loop;
end $$;


-- ============================================================================
-- Anvaya CRM — 003 growth features
-- Capture (web forms, inbound email), API access, outbound webhooks,
-- integration state, saved views and exchange rates.
-- ============================================================================

-- ------------------------------------------------------------- web forms ---
create table if not exists web_forms (
  id             uuid primary key default gen_random_uuid(),
  org_id         uuid not null references organisations(id) on delete cascade,
  name           text not null,
  slug           text not null unique,
  headline       text default 'Talk to us',
  description    text,
  fields         jsonb not null default '["name","email","phone","company_name","message"]',
  required       jsonb not null default '["name"]',
  success_message text not null default 'Thank you — we will be in touch shortly.',
  redirect_url   text,
  default_source text not null default 'web_form',
  owner_id       uuid references members(id) on delete set null,
  is_active      boolean not null default true,
  submission_count int not null default 0,
  created_by     uuid references users(id),
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);

create table if not exists form_submissions (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null references organisations(id) on delete cascade,
  form_id      uuid not null references web_forms(id) on delete cascade,
  lead_id      uuid references leads(id) on delete set null,
  payload      jsonb not null default '{}',
  ip           text,
  user_agent   text,
  is_duplicate boolean not null default false,
  created_at   timestamptz not null default now()
);
create index if not exists form_submissions_form on form_submissions (form_id, created_at desc);

-- -------------------------------------------------------------- api keys ---
create table if not exists api_keys (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  name        text not null,
  prefix      text not null,
  key_hash    text not null unique,
  scopes      text[] not null default '{"read"}',
  last_used_at timestamptz,
  request_count int not null default 0,
  created_by  uuid references users(id),
  revoked_at  timestamptz,
  created_at  timestamptz not null default now()
);
create index if not exists api_keys_org on api_keys (org_id) where revoked_at is null;

-- -------------------------------------------------------------- webhooks ---
create table if not exists webhooks (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null references organisations(id) on delete cascade,
  url          text not null,
  description  text,
  secret       text not null,
  events       text[] not null default '{}',
  is_active    boolean not null default true,
  last_status  text,
  last_error   text,
  last_fired_at timestamptz,
  failure_count int not null default 0,
  created_by   uuid references users(id),
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

create table if not exists webhook_deliveries (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references organisations(id) on delete cascade,
  webhook_id    uuid not null references webhooks(id) on delete cascade,
  event         text not null,
  payload       jsonb not null default '{}',
  status        text not null default 'pending' check (status in ('pending','delivered','failed')),
  response_code int,
  error         text,
  attempts      int not null default 1,
  created_at    timestamptz not null default now()
);
create index if not exists webhook_deliveries_wh on webhook_deliveries (webhook_id, created_at desc);

-- ----------------------------------------------------- integration state ---
alter table integrations add column if not exists tokens       text;   -- AES-256-GCM, never returned by the API
alter table integrations add column if not exists account      text;   -- provider account label, e.g. the mailbox
alter table integrations add column if not exists cursor       text;   -- delta sync marker
alter table integrations add column if not exists sync_state   jsonb not null default '{}';
alter table integrations add column if not exists last_synced_at timestamptz;

-- ----------------------------------------------------------- saved views ---
create table if not exists saved_views (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null references organisations(id) on delete cascade,
  user_id    uuid references users(id) on delete cascade,
  resource   text not null,
  name       text not null,
  filters    jsonb not null default '{}',
  sort       text,
  is_shared  boolean not null default false,
  created_at timestamptz not null default now()
);

-- -------------------------------------------------------- exchange rates ---
create table if not exists exchange_rates (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  currency    char(3) not null,
  rate_to_org numeric(16,6) not null,
  as_of       date not null default current_date,
  unique (org_id, currency, as_of)
);



-- --------------------------------------------------------------------- MFA ---
alter table users add column if not exists mfa_secret        text;
alter table users add column if not exists mfa_enabled_at    timestamptz;
alter table users add column if not exists mfa_backup_codes  text[] not null default '{}';
alter table users add column if not exists mfa_last_used_at  timestamptz;

-- A session created before the second factor is not usable until it is proven.
alter table sessions add column if not exists mfa_ok boolean not null default true;

-- Organisation-level enforcement lives in organisations.settings->>'require_mfa'.



-- ============================================================================
-- Anvaya CRM — 005 documents and finance
--
-- Additive only. Existing invoices, quotations and payments keep their rows and
-- their meaning; new columns are nullable or defaulted so V5 data reads the
-- same after the migration.
-- ============================================================================

-- ------------------------------------------------- document numbering -------
create table if not exists document_sequences (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  doc_type    text not null check (doc_type in ('quotation','invoice','receipt','credit_note','proposal')),
  prefix      text not null,
  next_number int not null default 1,
  padding     int not null default 4,
  unique (org_id, doc_type)
);

-- Every issued document is snapshotted, so a reprint in 2030 shows what the
-- customer was actually sent, not today's edited record.
create table if not exists document_versions (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  doc_type    text not null,
  entity_id   uuid not null,
  number      text not null,
  version     int not null default 1,
  snapshot    jsonb not null default '{}',
  totals      jsonb not null default '{}',
  issued_by   uuid references users(id),
  issued_at   timestamptz not null default now(),
  unique (org_id, doc_type, entity_id, version)
);
create index if not exists document_versions_entity on document_versions (org_id, doc_type, entity_id, version desc);

-- ------------------------------------------------------------- quotations ----
alter table quotations add column if not exists number        text;
alter table quotations add column if not exists tax_mode      text not null default 'cgst_sgst';
alter table quotations add column if not exists place_of_supply text;
alter table quotations add column if not exists notes         text;
alter table quotations add column if not exists terms         text;

-- --------------------------------------------------------------- invoices ----
alter table invoices add column if not exists number         text;
alter table invoices add column if not exists subtotal       numeric(16,2) not null default 0;
alter table invoices add column if not exists tax_total      numeric(16,2) not null default 0;
alter table invoices add column if not exists discount_total numeric(16,2) not null default 0;
alter table invoices add column if not exists currency       char(3) not null default 'INR';
alter table invoices add column if not exists tax_mode       text not null default 'cgst_sgst';
alter table invoices add column if not exists place_of_supply text;
alter table invoices add column if not exists notes          text;
alter table invoices add column if not exists terms          text;
alter table invoices add column if not exists reminder_sent_at timestamptz;
alter table invoices add column if not exists credited_amount numeric(16,2) not null default 0;

-- A due date already exists; make overdue detectable without a scan of text.
create index if not exists invoices_due on invoices (org_id, due_date) where status <> 'paid';

-- --------------------------------------------------------------- payments ----
alter table payments add column if not exists invoice_id     uuid references invoices(id) on delete set null;
alter table payments add column if not exists currency       char(3) not null default 'INR';
alter table payments add column if not exists provider       text not null default 'manual';
alter table payments add column if not exists provider_ref   text;
alter table payments add column if not exists reference      text;
alter table payments add column if not exists notes          text;
alter table payments add column if not exists recorded_by    uuid references users(id);
alter table payments add column if not exists idempotency_key text;
create unique index if not exists payments_idem on payments (org_id, idempotency_key)
  where idempotency_key is not null;

create table if not exists payment_links (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  invoice_id  uuid references invoices(id) on delete cascade,
  contact_id  uuid references contacts(id) on delete set null,
  token       text not null unique,
  amount      numeric(16,2) not null,
  currency    char(3) not null default 'INR',
  provider    text not null default 'manual',
  status      text not null default 'active' check (status in ('active','paid','expired','cancelled')),
  expires_at  timestamptz,
  paid_at     timestamptz,
  created_by  uuid references users(id),
  created_at  timestamptz not null default now()
);

create table if not exists refunds (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  payment_id  uuid not null references payments(id) on delete cascade,
  amount      numeric(16,2) not null check (amount > 0),
  reason      text,
  status      text not null default 'pending' check (status in ('pending','processed','failed')),
  provider_ref text,
  created_by  uuid references users(id),
  created_at  timestamptz not null default now(),
  processed_at timestamptz
);

create table if not exists credit_notes (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  invoice_id  uuid references invoices(id) on delete set null,
  contact_id  uuid references contacts(id) on delete set null,
  number      text not null,
  amount      numeric(16,2) not null check (amount > 0),
  reason      text,
  status      text not null default 'issued' check (status in ('issued','applied','void')),
  issued_at   timestamptz not null default now(),
  created_by  uuid references users(id)
);

-- --------------------------------------------------------------- webhooks ----
create table if not exists payment_events (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null references organisations(id) on delete cascade,
  provider     text not null,
  event_id     text not null,
  type         text not null,
  payload      jsonb not null default '{}',
  status       text not null default 'received' check (status in ('received','processed','failed','ignored')),
  error        text,
  received_at  timestamptz not null default now(),
  processed_at timestamptz,
  unique (provider, event_id)
);

-- ============================================================================
-- 02_rls.sql
-- ============================================================================

do $$
declare spec record;
begin
  for spec in
    select * from (values
      ('companies','company',true),
      ('contacts','contact',true),
      ('leads','lead',true),
      ('deals','deal',true),
      ('pipelines','pipeline',true),
      ('stages','pipeline',true),
      ('activities','activity',true),
      ('tasks','task',true),
      ('tickets','ticket',true),
      ('ticket_comments','ticket',true),
      ('knowledge_articles','ticket',true),
      ('campaigns','campaign',true),
      ('campaign_recipients','campaign',true),
      ('products','product',true),
      ('quotations','quotation',true),
      ('quotation_items','quotation',true),
      ('invoices','invoice',true),
      ('invoice_items','invoice',true),
      ('payments','payment',false),
      ('projects','project',true),
      ('milestones','project',true),
      ('workflows','workflow',true),
      ('workflow_runs','workflow',false),
      ('workflow_steps','workflow',false),
      ('ai_runs','ai',false),
      ('ai_actions','ai',false),
      ('custom_fields','settings',true),
      ('custom_values','settings',true),
      ('integrations','integration',true),
      ('workspaces','workspace',true),
      ('roles','settings',true),
      ('members','member',true),
      ('subscriptions','billing',false)
    ) as v(tbl, perm, can_delete)
  loop
    execute format('alter table %I enable row level security', spec.tbl);
    execute format('alter table %I force row level security', spec.tbl);

    execute format('drop policy if exists %I on %I', spec.tbl || '_sel', spec.tbl);
    execute format(
      'create policy %I on %I for select using (org_id = app.current_org())',
      spec.tbl || '_sel', spec.tbl);

    execute format('drop policy if exists %I on %I', spec.tbl || '_ins', spec.tbl);
    execute format(
      'create policy %I on %I for insert with check (org_id = app.current_org() and app.has_perm(%L))',
      spec.tbl || '_ins', spec.tbl, spec.perm || '.write');

    execute format('drop policy if exists %I on %I', spec.tbl || '_upd', spec.tbl);
    execute format(
      'create policy %I on %I for update using (org_id = app.current_org() and app.has_perm(%L)) with check (org_id = app.current_org())',
      spec.tbl || '_upd', spec.tbl, spec.perm || '.write');

    if spec.can_delete then
      execute format('drop policy if exists %I on %I', spec.tbl || '_del', spec.tbl);
      execute format(
        'create policy %I on %I for delete using (org_id = app.current_org() and app.has_perm(%L))',
        spec.tbl || '_del', spec.tbl, spec.perm || '.delete');
    end if;
  end loop;
end $$;

-- --------------------------------------------------------------- specials ---

-- organisations: a member sees only their own organisation
alter table organisations enable row level security;
alter table organisations force row level security;
drop policy if exists organisations_sel on organisations;
create policy organisations_sel on organisations for select
  using (id = app.current_org());
drop policy if exists organisations_upd on organisations;
create policy organisations_upd on organisations for update
  using (id = app.current_org() and app.has_perm('settings.write'))
  with check (id = app.current_org());

-- users: yourself, plus colleagues in the same organisation
alter table users enable row level security;
alter table users force row level security;
drop policy if exists users_sel on users;
create policy users_sel on users for select
  using (
    id = app.current_user()
    or exists (select 1 from members m where m.user_id = users.id and m.org_id = app.current_org())
  );
drop policy if exists users_upd on users;
create policy users_upd on users for update
  using (id = app.current_user())
  with check (id = app.current_user());

-- notifications: strictly your own
alter table notifications enable row level security;
alter table notifications force row level security;
drop policy if exists notifications_sel on notifications;
create policy notifications_sel on notifications for select
  using (user_id = app.current_user() and org_id = app.current_org());
drop policy if exists notifications_upd on notifications;
create policy notifications_upd on notifications for update
  using (user_id = app.current_user() and org_id = app.current_org())
  with check (user_id = app.current_user() and org_id = app.current_org());
drop policy if exists notifications_ins on notifications;
create policy notifications_ins on notifications for insert
  with check (org_id = app.current_org() and app.has_perm('notification.write'));

-- audit_logs: readable, never writable by application users.
-- Rows are written by the system connection so a user cannot forge or erase
-- their own trail.
alter table audit_logs enable row level security;
alter table audit_logs force row level security;
drop policy if exists audit_sel on audit_logs;
create policy audit_sel on audit_logs for select
  using (org_id = app.current_org() and app.has_perm('audit.read'));

-- sessions: no policy at all. Only the auth layer (system connection) reads
-- them, so a compromised request context cannot enumerate other sessions.
alter table sessions enable row level security;
alter table sessions force row level security;


do $$
declare spec record;
begin
  for spec in
    select * from (values
      ('web_forms','settings',true),
      ('form_submissions','settings',false),
      ('api_keys','settings',true),
      ('webhooks','settings',true),
      ('webhook_deliveries','settings',false),
      ('saved_views','lead',true),
      ('exchange_rates','settings',true)
    ) as v(tbl, perm, can_delete)
  loop
    execute format('alter table %I enable row level security', spec.tbl);
    execute format('alter table %I force row level security', spec.tbl);
    execute format('drop policy if exists %I on %I', spec.tbl || '_sel', spec.tbl);
    execute format('create policy %I on %I for select using (org_id = app.current_org())',
      spec.tbl || '_sel', spec.tbl);
    execute format('drop policy if exists %I on %I', spec.tbl || '_ins', spec.tbl);
    execute format('create policy %I on %I for insert with check (org_id = app.current_org() and app.has_perm(%L))',
      spec.tbl || '_ins', spec.tbl, spec.perm || '.write');
    execute format('drop policy if exists %I on %I', spec.tbl || '_upd', spec.tbl);
    execute format('create policy %I on %I for update using (org_id = app.current_org() and app.has_perm(%L)) with check (org_id = app.current_org())',
      spec.tbl || '_upd', spec.tbl, spec.perm || '.write');
    if spec.can_delete then
      execute format('drop policy if exists %I on %I', spec.tbl || '_del', spec.tbl);
      execute format('create policy %I on %I for delete using (org_id = app.current_org() and app.has_perm(%L))',
        spec.tbl || '_del', spec.tbl, spec.perm || '.delete');
    end if;
  end loop;
end $$;

-- api keys are read by the auth layer on the system connection, so the
-- application role only ever sees its own organisation's keys.


do $$
declare spec record;
begin
  for spec in select * from (values
      ('document_sequences','quotation',true),
      ('document_versions','quotation',false),
      ('payment_links','payment',true),
      ('refunds','payment',true),
      ('credit_notes','invoice',true),
      ('payment_events','payment',false)
    ) as v(tbl, perm, can_delete)
  loop
    execute format('alter table %I enable row level security', spec.tbl);
    execute format('alter table %I force row level security', spec.tbl);
    execute format('drop policy if exists %I on %I', spec.tbl || '_sel', spec.tbl);
    execute format('create policy %I on %I for select using (org_id = app.current_org() and app.has_perm(%L))',
      spec.tbl || '_sel', spec.tbl, spec.perm || '.read');
    execute format('drop policy if exists %I on %I', spec.tbl || '_ins', spec.tbl);
    execute format('create policy %I on %I for insert with check (org_id = app.current_org() and app.has_perm(%L))',
      spec.tbl || '_ins', spec.tbl, spec.perm || '.write');
    execute format('drop policy if exists %I on %I', spec.tbl || '_upd', spec.tbl);
    execute format('create policy %I on %I for update using (org_id = app.current_org() and app.has_perm(%L)) with check (org_id = app.current_org())',
      spec.tbl || '_upd', spec.tbl, spec.perm || '.write');
    if spec.can_delete then
      execute format('drop policy if exists %I on %I', spec.tbl || '_del', spec.tbl);
      execute format('create policy %I on %I for delete using (org_id = app.current_org() and app.has_perm(%L))',
        spec.tbl || '_del', spec.tbl, spec.perm || '.delete');
    end if;
  end loop;
end $$;

-- ============================================================================
-- 03_seed.sql
-- ============================================================================

do $$
declare
  v_email   text := 'you@yourcompany.com';   -- <-- the account that owns this workspace
  v_org     text := 'Your Company';
  v_slug    text := 'your-company';
  v_user    uuid;
  v_org_id  uuid;
  v_role    uuid;
begin
  if exists (select 1 from organisations where slug = v_slug) then
    raise notice 'Workspace % already exists — nothing to do', v_slug;
    return;
  end if;

  -- The user must already exist. On Supabase Auth, create the account first
  -- (Authentication → Users) and this finds it by email.
  select id into v_user from users where lower(email) = lower(v_email) limit 1;
  if v_user is null then
    -- Not an error: the account may not exist yet. The rest of the file is
    -- already applied; run this section again once the user is created.
    raise notice 'No user with email % yet. Create the account, then re-run section 04.', v_email;
    return;
  end if;

  insert into organisations (name, slug, currency, timezone)
  values (v_org, v_slug, 'INR', 'Asia/Kolkata')
  returning id into v_org_id;

  insert into workspaces (org_id, name, slug, is_default)
  values (v_org_id, 'Main', 'main', true);

  -- Role templates, identical to the ones the application ships with.
  insert into roles (org_id, key, name, description, permissions) values
      (v_org_id, 'owner', 'Owner', 'Full access including billing, roles and deletion', '{*}'::text[]),
      (v_org_id, 'admin', 'Org admin', 'Everything except ownership transfer and workspace deletion', '{activity.delete,activity.read,activity.write,ai.delete,ai.read,ai.write,billing.delete,billing.read,billing.write,campaign.delete,campaign.read,campaign.write,company.delete,company.read,company.write,contact.delete,contact.read,contact.write,deal.delete,deal.read,deal.write,integration.delete,integration.read,integration.write,invoice.delete,invoice.read,invoice.write,lead.delete,lead.read,lead.write,member.delete,member.read,member.write,notification.delete,notification.read,notification.write,payment.delete,payment.read,payment.write,pipeline.delete,pipeline.read,pipeline.write,product.delete,product.read,product.write,project.delete,project.read,project.write,quotation.delete,quotation.read,quotation.write,settings.delete,settings.read,settings.write,task.delete,task.read,task.write,ticket.delete,ticket.read,ticket.write,workflow.delete,workflow.read,workflow.write,workspace.delete,workspace.read,workspace.write,audit.read,report.read}'::text[]),
      (v_org_id, 'manager', 'Manager', 'Team records, approvals and every report', '{activity.delete,activity.read,activity.write,ai.read,ai.write,campaign.read,campaign.write,company.delete,company.read,company.write,contact.delete,contact.read,contact.write,deal.delete,deal.read,deal.write,invoice.read,invoice.write,lead.delete,lead.read,lead.write,member.read,notification.read,notification.write,pipeline.read,pipeline.write,product.read,project.delete,project.read,project.write,quotation.read,quotation.write,report.read,settings.read,task.delete,task.read,task.write,ticket.delete,ticket.read,ticket.write,workflow.read,workflow.write,audit.read,report.read}'::text[]),
      (v_org_id, 'sales', 'Sales representative', 'Own pipeline, contacts and quotations', '{activity.read,activity.write,ai.read,ai.write,company.read,company.write,contact.read,contact.write,deal.read,deal.write,lead.read,lead.write,member.read,notification.read,notification.write,pipeline.read,product.read,project.read,quotation.read,quotation.write,task.read,task.write,ticket.read,report.read}'::text[]),
      (v_org_id, 'support', 'Support agent', 'Tickets, customer records and knowledge base', '{activity.read,activity.write,ai.read,ai.write,company.read,contact.read,contact.write,deal.read,member.read,notification.read,notification.write,project.read,task.read,task.write,ticket.delete,ticket.read,ticket.write}'::text[]),
      (v_org_id, 'marketing', 'Marketing', 'Campaigns, segments and lead capture', '{activity.read,activity.write,ai.read,ai.write,campaign.delete,campaign.read,campaign.write,contact.read,contact.write,lead.read,lead.write,member.read,notification.read,notification.write,product.read,task.read,task.write,report.read}'::text[]),
      (v_org_id, 'finance', 'Finance', 'Quotations, invoices and payments', '{company.read,contact.read,deal.read,invoice.delete,invoice.read,invoice.write,member.read,notification.read,notification.write,payment.read,payment.write,product.read,quotation.read,quotation.write,report.read}'::text[]),
      (v_org_id, 'field', 'Field employee', 'Assigned visits, tasks and customer context', '{activity.read,activity.write,company.read,contact.read,deal.read,member.read,notification.read,notification.write,task.read,task.write,ticket.read,ticket.write}'::text[]),
      (v_org_id, 'readonly', 'Read-only', 'View and export where permitted, no writes', '{lead.read,contact.read,company.read,deal.read,pipeline.read,activity.read,task.read,ticket.read,campaign.read,product.read,quotation.read,invoice.read,payment.read,project.read,workflow.read,ai.read,settings.read,billing.read,integration.read,member.read,workspace.read,notification.read,report.read}'::text[]);

  select id into v_role from roles where org_id = v_org_id and key = 'owner';
  insert into members (org_id, user_id, role_id, status, title)
  values (v_org_id, v_user, v_role, 'active', 'Owner');

  insert into pipelines (org_id, name, is_default)
  values (v_org_id, 'Sales pipeline', true);

  insert into stages (org_id, pipeline_id, name, position, probability, is_won, is_lost)
  select v_org_id, p.id, s.name, s.position, s.probability, s.is_won, s.is_lost
    from pipelines p,
         (values ('Discovery', 1, 20, false, false),
                 ('Site survey', 2, 35, false, false),
                 ('Proposal sent', 3, 55, false, false),
                 ('Negotiation', 4, 75, false, false),
                 ('Closed won', 5, 100, true, false),
                 ('Closed lost', 6, 0, false, true)) as s(name, position, probability, is_won, is_lost)
   where p.org_id = v_org_id;

  insert into subscriptions (org_id, plan, status, seats)
  values (v_org_id, 'professional', 'active', 5)
  on conflict do nothing;

  insert into document_sequences (org_id, doc_type, prefix)
  values (v_org_id, 'quotation', 'QTN'),
         (v_org_id, 'invoice', 'INV'),
         (v_org_id, 'credit_note', 'CRN'),
         (v_org_id, 'receipt', 'RCT')
  on conflict do nothing;

  raise notice 'Workspace % created for %', v_org, v_email;
end $$;

-- ============================================================================
-- 05_functions.sql — logic that must run in the database
-- ============================================================================

-- ---------------------------------------------------------------- numbering --
create or replace function app.next_number(p_type text)
returns text
language plpgsql
as $$
declare
  v_prefix text;
  v_seq int;
  v_pad int;
  v_year text := to_char(now(), 'YYYY');
begin
  if app.current_org() is null then
    raise exception 'No organisation in context';
  end if;

  insert into document_sequences (org_id, doc_type, prefix, next_number)
  values (app.current_org(), p_type,
          case p_type when 'invoice' then 'INV' when 'quotation' then 'QTN'
                      when 'credit_note' then 'CRN' when 'receipt' then 'RCT'
                      else upper(left(p_type, 3)) end,
          2)
  on conflict (org_id, doc_type)
    do update set next_number = document_sequences.next_number + 1
  returning prefix, next_number - 1, padding into v_prefix, v_seq, v_pad;

  return v_prefix || '-' || v_year || '-' || lpad(v_seq::text, v_pad, '0');
end $$;

-- --------------------------------------------------------------- invoices ----
-- Totals are computed here, never sent by the client.
create or replace function app.recalculate_invoice(p_invoice uuid)
returns jsonb
language plpgsql
as $$
declare
  v_inv invoices%rowtype;
  v_paid numeric := 0;
  v_refunded numeric := 0;
  v_credited numeric := 0;
  v_outstanding numeric;
  v_status text;
begin
  select * into v_inv from invoices where id = p_invoice;
  if not found then
    raise exception 'Invoice % not found', p_invoice using errcode = 'P0002';
  end if;

  select coalesce(sum(amount), 0) into v_paid
    from payments where invoice_id = p_invoice and status = 'succeeded';

  select coalesce(sum(r.amount), 0) into v_refunded
    from refunds r join payments p on p.id = r.payment_id
   where p.invoice_id = p_invoice and r.status = 'processed';

  select coalesce(sum(amount), 0) into v_credited
    from credit_notes where invoice_id = p_invoice and status <> 'void';

  v_paid := greatest(v_paid - v_refunded, 0);
  v_outstanding := greatest(round(v_inv.total - v_paid - v_credited, 2), 0);

  v_status := case
    when v_outstanding <= 0.009 then 'paid'
    when v_paid > 0 then 'partially_paid'
    when v_inv.due_date is not null and v_inv.due_date < current_date then 'overdue'
    when v_inv.status = 'draft' then 'draft'
    else 'sent'
  end;

  update invoices
     set amount_paid = v_paid, credited_amount = v_credited, status = v_status, updated_at = now()
   where id = p_invoice;

  return jsonb_build_object(
    'amount', v_inv.total, 'paid', v_paid, 'credited', v_credited,
    'outstanding', v_outstanding, 'status', v_status, 'currency', v_inv.currency
  );
end $$;

create or replace function app.create_invoice(
  p_items jsonb,
  p_contact uuid default null,
  p_company uuid default null,
  p_tax_mode text default 'cgst_sgst',
  p_discount numeric default 0,
  p_due_date date default null,
  p_notes text default null
) returns jsonb
language plpgsql
as $$
declare
  v_item jsonb;
  v_gross numeric := 0;
  v_tax numeric := 0;
  v_subtotal numeric := 0;
  v_total numeric;
  v_line_taxable numeric;
  v_qty numeric;
  v_rate numeric;
  v_tax_rate numeric;
  v_disc numeric;
  v_number text;
  v_id uuid;
  v_pos int := 0;
begin
  if p_items is null or jsonb_array_length(p_items) = 0 then
    raise exception 'An invoice needs at least one line item' using errcode = '22023';
  end if;

  v_number := app.next_number('invoice');

  insert into invoices (org_id, contact_id, company_id, number, status, issue_date, due_date,
                        total, subtotal, tax_total, discount_total, currency, tax_mode, notes, amount_paid)
  values (app.current_org(), p_contact, p_company, v_number, 'sent', current_date,
          coalesce(p_due_date, current_date + 15), 0, 0, 0, coalesce(p_discount, 0), 'INR', p_tax_mode, p_notes, 0)
  returning id into v_id;

  for v_item in select * from jsonb_array_elements(p_items) loop
    v_pos := v_pos + 1;
    v_qty := coalesce((v_item->>'quantity')::numeric, 1);
    v_rate := coalesce((v_item->>'unit_price')::numeric, 0);
    v_tax_rate := coalesce((v_item->>'tax_rate')::numeric, 0);
    v_disc := coalesce((v_item->>'discount')::numeric, 0);

    v_gross := v_gross + v_qty * v_rate;
    v_line_taxable := greatest(v_qty * v_rate - v_disc, 0);
    v_subtotal := v_subtotal + v_line_taxable;
    v_tax := v_tax + round(v_line_taxable * v_tax_rate, 2) / 100;

    insert into invoice_items (org_id, invoice_id, description, qty, unit_price, tax_rate, line_total, position)
    values (app.current_org(), v_id, coalesce(v_item->>'description', 'Item'),
            v_qty, v_rate, v_tax_rate, v_line_taxable, v_pos);
  end loop;

  -- An order-level discount reduces the taxable value, so tax follows it.
  if coalesce(p_discount, 0) > 0 and v_subtotal > 0 then
    v_tax := round(v_tax * greatest(v_subtotal - p_discount, 0) / v_subtotal, 2);
  end if;

  v_total := round(v_subtotal - coalesce(p_discount, 0) + v_tax, 2);

  update invoices
     set subtotal = v_subtotal, tax_total = v_tax, total = v_total
   where id = v_id;

  return jsonb_build_object(
    'id', v_id, 'number', v_number, 'subtotal', v_subtotal,
    'tax_total', v_tax, 'discount_total', coalesce(p_discount, 0), 'total', v_total,
    'balance', app.recalculate_invoice(v_id)
  );
end $$;

-- ------------------------------------------------------------ lead convert ---
-- One call does what the "Turn into deal" button does: company, contact, deal
-- and an activity, atomically.
create or replace function app.convert_lead(p_lead uuid)
returns jsonb
language plpgsql
as $$
declare
  v_lead leads%rowtype;
  v_company uuid;
  v_contact uuid;
  v_deal uuid;
  v_pipeline uuid;
  v_stage uuid;
begin
  select * into v_lead from leads where id = p_lead;
  if not found then
    raise exception 'Lead % not found', p_lead using errcode = 'P0002';
  end if;
  if v_lead.converted_deal_id is not null then
    raise exception 'That lead has already been converted' using errcode = '23505';
  end if;

  if v_lead.company_name is not null then
    select id into v_company from companies where lower(name) = lower(v_lead.company_name) limit 1;
    if v_company is null then
      insert into companies (org_id, name, owner_id)
      values (app.current_org(), v_lead.company_name, v_lead.owner_id)
      returning id into v_company;
    end if;
  end if;

  if v_lead.email is not null then
    select id into v_contact from contacts where lower(email) = lower(v_lead.email) limit 1;
  end if;
  if v_contact is null then
    insert into contacts (org_id, first_name, last_name, email, phone, company_id, owner_id)
    values (app.current_org(),
            split_part(coalesce(v_lead.name, 'Unknown'), ' ', 1),
            nullif(substr(coalesce(v_lead.name, ''), position(' ' in coalesce(v_lead.name, '')) + 1), ''),
            v_lead.email, v_lead.phone, v_company, v_lead.owner_id)
    returning id into v_contact;
  end if;

  select id into v_pipeline from pipelines where is_default = true limit 1;
  select id into v_stage from stages where pipeline_id = v_pipeline order by position limit 1;

  insert into deals (org_id, pipeline_id, stage_id, company_id, contact_id, title, value, owner_id,
                     probability, expected_close_date, status, source_lead_id)
  values (app.current_org(), v_pipeline, v_stage, v_company, v_contact,
          coalesce(v_lead.company_name, v_lead.name, 'New deal'),
          coalesce(v_lead.estimated_value, 0), v_lead.owner_id,
          coalesce((select probability from stages where id = v_stage), 20),
          current_date + 30, 'open', v_lead.id)
  returning id into v_deal;

  insert into activities (org_id, type, subject, body, contact_id, company_id, deal_id, occurred_at)
  values (app.current_org(), 'note', 'Lead converted',
          'Created from the lead: ' || coalesce(v_lead.name, ''), v_contact, v_company, v_deal, now());

  update leads
     set status = 'converted', converted_contact_id = v_contact, converted_deal_id = v_deal
   where id = p_lead;

  return jsonb_build_object('contact_id', v_contact, 'company_id', v_company, 'deal_id', v_deal);
end $$;

-- ---------------------------------------------------------------- dashboard --
-- One round trip instead of six, for the home screen.
create or replace function app.dashboard()
returns jsonb
language sql
stable
as $$
  with d as (
    select * from deals
  )
  select jsonb_build_object(
    'open_deals', (select count(*) from d where status = 'open'),
    'pipeline_value', (select coalesce(sum(value), 0) from d where status = 'open'),
    'won_value', (select coalesce(sum(value), 0) from d where status = 'won'),
    'won_count', (select count(*) from d where status = 'won'),
    'new_leads', (select count(*) from leads where status = 'new'),
    'open_tickets', (select count(*) from tickets where resolved_at is null),
    'sla_breaches', (select count(*) from tickets where resolved_at is null and sla_due_at < now()),
    'open_tasks', (select count(*) from tasks where status <> 'done'),
    'overdue_tasks', (select count(*) from tasks where status <> 'done' and due_date < current_date),
    'outstanding', (select coalesce(sum(total - amount_paid - credited_amount), 0)
                      from invoices where status <> 'paid')
  )
$$;

-- ------------------------------------------------------------- permissions ---
grant execute on function app.next_number(text) to authenticated;
grant execute on function app.recalculate_invoice(uuid) to authenticated;
grant execute on function app.create_invoice(jsonb, uuid, uuid, text, numeric, date, text) to authenticated;
grant execute on function app.convert_lead(uuid) to authenticated;
grant execute on function app.dashboard() to authenticated;
