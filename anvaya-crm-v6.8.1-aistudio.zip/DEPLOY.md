# Deployment

Two independent deployments. Pick the one you need; they do not interfere.

---

## A. The app as a static site (Vercel, Netlify, GitHub Pages, Cloudflare Pages)

**What you upload:** this folder, or `anvaya-crm-v3.zip`.

```
index.html          app.js        engine.js      data.js        styles.css
pwa.js              sw.js         manifest.webmanifest         icons/  favicon.ico
```

`index.html` must sit at the root of the deployment. That is the whole fix for the
unstyled page you saw: when it lived inside `web/`, the host served the HTML but
`styles.css` resolved against the wrong directory and 404'd. No `package.json`, no `api/`, no `vercel.json`. That is deliberate — every
deployment failure in this project came from a platform guessing that the folder was a
Node app. With none of those files present there is nothing to guess.

### Vercel

1. vercel.com/new → **Deploy** → drag `anvaya-crm-v3.zip`
2. Framework Preset: **Other**
3. Build Command: leave empty · Output Directory: leave empty · Install Command: empty
4. Deploy

If you are redeploying into a project that once held the Node version, either create a
**new** project or, on the redeploy dialog, untick **Use existing build cache** — that
cache is what kept the old Node settings alive.

### Netlify (fastest, no build step at all)

Open `app.netlify.com/drop` and drag the `web` folder in. Done.

### GitHub Pages

Put the five files in a repo, Settings → Pages → Deploy from branch → `/ (root)`.

### Install it as an app

Once the site is live over HTTPS (which every host above provides), it is installable:

- **Windows / macOS, Chrome or Edge:** install icon in the address bar, or menu →
  Apps → *Install this site as an app*. Safari on macOS: Share → *Add to Dock*.
- **Android, Chrome:** menu → *Install app*. The in-app **Install app** button triggers
  the same prompt.
- **iOS / iPadOS:** must be Safari → Share → *Add to Home Screen*. iOS does not allow
  Chrome or any browser to install a PWA.

The manifest, service worker and icons are already in the repo, so nothing extra is
needed. The installed app opens in its own window, keeps working offline (the shell is
cached; live API calls are never cached), and stores data on the device.

### What you get

The full CRM, single-user, with records stored in the visitor's browser. It survives
reloads and restarts on that device; it is not shared and it is not on a server. The
sidebar has a **Reset demo data** button.

---

## B. The backend (Railway, Render, Fly.io, a VPS)

`backend/` runs PostgreSQL in-process and writes its data directory to disk, so it needs
a **writable filesystem and a long-running process**. That rules out Vercel functions,
Netlify functions and any other serverless host — this is the constraint that produced
`FUNCTION_INVOCATION_FAILED` when the whole repo was uploaded to Vercel.

### Railway

1. New Project → Deploy from repo (or upload `backend/`)
2. Start command: `npm start`
3. Variables: `NODE_ENV=production`, `PORT` (Railway sets it), optionally `AI_API_KEY`
4. Add a **volume** mounted at `/app/.data` so the database survives redeploys
5. Run the seed once from the shell: `npm run seed`

### Render

New → Web Service → root directory `backend`, build `npm install`, start `npm start`,
plus a persistent disk mounted at `/opt/render/project/src/.data`.

### Then connect the app to it

Add one line inside `<head>` of `index.html`:

```html
<meta name="anvaya-api" content="https://your-backend.up.railway.app">
```

and set on the backend:

```
CORS_ORIGIN=https://your-site.vercel.app
```

Reload the site. The header chip changes from *Saved in this browser* to *Live data*,
and every visitor now shares the same records. Nothing is rebuilt; the app probes
`GET /api/health` and takes the server path when it answers `{ "mode": "server" }`.

---

## C. Moving the database to Supabase (optional, later)

The SQL is plain PostgreSQL and applies unchanged.

1. In the Supabase SQL editor, run `backend/db/migrations/001_schema.sql`, then
   `002_rls.sql`. You get 38 tables and 134 row-level-security policies.
2. Replace the PGlite client in `backend/src/db.js` with `pg`:
   `new Client({ connectionString: process.env.DATABASE_URL, ssl: { rejectUnauthorized: false } })`.
   `q`, `tx` and `asUser` keep their signatures; `asUser` becomes
   `BEGIN; SET LOCAL ROLE app_user; SELECT set_config('app.org_id', …, true); …; COMMIT;`.
3. Set `DATABASE_URL` on the backend and redeploy. The embedded database is no longer used.

---

## D. Turning on the optional features

Everything below is off until you supply credentials. Each one fails with a message naming
the exact variable to set, and nothing shows as "connected" until a provider confirms it.

| Feature | Variables | Where to get them |
|---|---|---|
| Gmail / Google Calendar | `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `ENCRYPTION_KEY` | console.cloud.google.com → Credentials → OAuth client (Web). Redirect URI: `{PUBLIC_API_URL}/api/integrations/callback` |
| Outlook / Microsoft Calendar | `MS_CLIENT_ID`, `MS_CLIENT_SECRET`, `ENCRYPTION_KEY` | portal.azure.com → App registrations. Same redirect URI. |
| Email-to-lead | `INBOUND_SECRET`, `INBOUND_ORG_ID` | Any inbound-email provider (Postmark, SendGrid, Mailgun). Point it at `POST /api/inbound/email`, sign the raw body with HMAC-SHA256, send the digest in `x-anvaya-signature`. |
| API keys / Zapier / Make | none — create keys in Settings | Spec at `/api/openapi.json` |
| Outbound webhooks | none — create in Settings | https only (localhost http allowed for testing) |

`ENCRYPTION_KEY` must be at least 32 characters: `openssl rand -base64 48`. Without it,
provider tokens are refused rather than stored in the clear.

---

## Troubleshooting the errors you actually saw

| Message | Cause | Fix |
|---|---|---|
| `500 FUNCTION_INVOCATION_FAILED` | Vercel tried to run the Express server; it writes a database directory to a read-only filesystem | Deploy the repo root as a static site (A); `backend/` is ignored by `.vercelignore`. |
| `Cannot read properties of undefined (reading 'fsPath')` | The project was created from the Node build and still carries that framework preset and build cache | New project, or set Framework Preset to **Other** and untick *Use existing build cache* on redeploy |
| `EACCES: permission denied, mkdir` | The embedded database cannot write its data directory | Host the backend where the disk is writable (B) |
| App loads but shows sample data | No backend reachable, so the local engine is running | Expected in static mode. Add the `<meta name="anvaya-api">` line to use a server. |
| Page loads with **no styling** (plain HTML, both sign-in forms visible) | `index.html` is not at the deployment root, so `styles.css` 404s | Deploy this repo root, not a subfolder. Check `/styles.css` returns 200. |
| No **Install app** button | The site is not on HTTPS, or the browser has no install support | Use the host's HTTPS URL. On iOS the button shows manual instructions instead. |
