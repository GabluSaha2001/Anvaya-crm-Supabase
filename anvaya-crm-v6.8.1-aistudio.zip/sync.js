/* ============================================================================
   Anvaya CRM — synchronisation engine
   ---------------------------------------------------------------------------
   Two-way sync between the local database and the server.

     pull   ask each table for rows changed since the last cursor, merge them in
     push   replay queued changes, oldest first, checking for conflicts

   Conflict rule — the one that matters: a local edit is applied only if the
   server row has not changed since the edit was made. If it has, the server's
   version wins the record and the local version is filed under "conflicts" for
   a person to look at. Nothing is silently dropped, and nothing silently
   overwrites.

   Everything is injected (store, api) so the rules can be tested without a
   browser or a network.
   ========================================================================== */
(function (root) {
  'use strict';

  const BOOKKEEPING = ['_dirty', '_base', '_deleted', '_queuedAt'];

  function strip(row) {
    const out = {};
    for (const [k, v] of Object.entries(row)) {
      if (!BOOKKEEPING.includes(k)) out[k] = v;
    }
    return out;
  }

  function newer(a, b) {
    if (!a) return false;
    if (!b) return true;
    return new Date(a).getTime() > new Date(b).getTime();
  }

  function createSync({ store, api, tables, onEvent = () => {}, now = () => Date.now() }) {
    let running = false;

    /* ------------------------------------------------------------- pull ---- */
    /**
     * Fetch rows changed since the cursor for every table and merge them in.
     * Returns counts, so the UI can say "3 new records".
     */
    async function pull({ since = null } = {}) {
      const result = { tables: 0, rows: 0, conflicts: 0, errors: [] };

      for (const table of tables) {
        const cursorKey = `cursor:${table}`;
        const cursor = since || await store.meta(cursorKey);
        try {
          const res = await api(`/api/${table}?limit=200${cursor ? `&updated_since=${encodeURIComponent(cursor)}` : ''}`);
          const rows = (res && res.data) || [];
          result.tables += 1;

          let newest = cursor;
          for (const remote of rows) {
            const local = await store.get(table, remote.id);

            if (local && local._dirty) {
              // Both sides moved. Compare the base the edit was made from with
              // what the server now holds.
              const serverMoved = newer(remote.updated_at, local._base);
              if (serverMoved) {
                await store.conflictAdd({
                  id: `${table}:${remote.id}:${now()}`,
                  table, recordId: remote.id,
                  local: strip(local), server: remote,
                  detectedAt: new Date(now()).toISOString()
                });
                result.conflicts += 1;
                // The server keeps the record; the local copy is preserved above.
                await store.put(table, { ...remote, _dirty: 0 });
              } else {
                // Local edit is newer than what the server has: keep it, the
                // push will carry it up.
                await store.put(table, { ...local, _dirty: 1 });
              }
            } else if (remote.deleted_at) {
              await store.remove(table, remote.id);
            } else {
              await store.put(table, { ...remote, _dirty: 0 });
            }

            if (newer(remote.updated_at, newest)) newest = remote.updated_at;
            result.rows += 1;
          }

          if (newest) await store.setMeta(cursorKey, newest);
        } catch (err) {
          if (err && err.status) result.errors.push({ table, error: err.message });
          else throw err;          // network: let the caller decide
        }
      }

      onEvent({ type: 'pull', ...result });
      return result;
    }

    /* ------------------------------------------------------------- push ---- */
    async function push() {
      const result = { sent: 0, conflicts: 0, failed: 0, pending: 0 };
      const queue = await store.outboxList();

      for (const item of queue) {
        const row = await store.get(item.table, item.recordId);
        try {
          // A change made offline must not overwrite a newer server row.
          if (item.method === 'PATCH' || item.method === 'DELETE') {
            const current = await api(`/api/${item.table}/${item.recordId}`);
            if (newer(current.updated_at, item.base)) {
              await store.conflictAdd({
                id: `${item.table}:${item.recordId}:${now()}`,
                table: item.table, recordId: item.recordId,
                local: item.body || (row ? strip(row) : null), server: current,
                detectedAt: new Date(now()).toISOString()
              });
              await store.outboxRemove(item.id);
              await store.put(item.table, { ...current, _dirty: 0 });
              result.conflicts += 1;
              continue;
            }
          }

          let saved;
          if (item.method === 'POST') {
            saved = await api(`/api/${item.table}`, { method: 'POST', body: item.body });
          } else if (item.method === 'PATCH') {
            saved = await api(`/api/${item.table}/${item.recordId}`, { method: 'PATCH', body: item.body });
          } else {
            await api(`/api/${item.table}/${item.recordId}`, { method: 'DELETE' });
            saved = null;
          }

          await store.outboxRemove(item.id);
          if (saved) await store.put(item.table, { ...saved, _dirty: 0 });
          else if (item.method === 'DELETE') await store.remove(item.table, item.recordId);
          result.sent += 1;
        } catch (err) {
          if (err && err.status >= 400 && err.status < 500) {
            // The server refused it; retrying will not help.
            await store.outboxRemove(item.id);
            result.failed += 1;
          } else {
            result.pending = queue.length - result.sent;
            break;                 // network: stop, keep the rest queued
          }
        }
      }

      result.pending = (await store.outboxList()).length;
      onEvent({ type: 'push', ...result });
      return result;
    }

    /* -------------------------------------------------------------- all ---- */
    async function syncAll() {
      if (running) return { skipped: true };
      running = true;
      try {
        const pushed = await push();
        const pulled = await pull();
        onEvent({ type: 'done', pushed, pulled });
        return { pushed, pulled };
      } finally {
        running = false;
      }
    }

    /* ------------------------------------------------------------ record --- */
    /** Apply a local change: write it now, queue it for the server. */
    async function save(table, row, method = 'POST', baseUpdatedAt = null) {
      const local = {
        ...strip(row),
        id: row.id || `local-${now()}-${Math.random().toString(36).slice(2, 7)}`,
        _dirty: 1,
        _base: baseUpdatedAt || row.updated_at || null
      };
      await store.put(table, local);
      await store.outboxAdd({
        id: `q-${now()}-${Math.random().toString(36).slice(2, 7)}`,
        table,
        recordId: local.id,
        method,
        body: strip(row),
        base: baseUpdatedAt || row.updated_at || null,
        queuedAt: now()
      });
      return local;
    }

    async function remove(table, id, baseUpdatedAt = null) {
      await store.put(table, { id, _deleted: 1, _dirty: 1, _base: baseUpdatedAt });
      await store.outboxAdd({
        id: `q-${now()}-${Math.random().toString(36).slice(2, 7)}`,
        table, recordId: id, method: 'DELETE', body: null,
        base: baseUpdatedAt, queuedAt: now()
      });
    }

    return { pull, push, syncAll, save, remove, strip, BOOKKEEPING };
  }

  root.AnvayaSync = { create: createSync, strip };
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { create: createSync, strip: strip };
  }
})(typeof window !== 'undefined' ? window : globalThis);
