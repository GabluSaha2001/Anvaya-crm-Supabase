/* ============================================================================
   Anvaya CRM — Supabase client (browser)
   ---------------------------------------------------------------------------
   Primary backend when online. Credentials come from (in order):

     1. window.__ANVAYA_SUPABASE__  (set by AI Studio / host)
     2. <meta name="anvaya-supabase-url"> + <meta name="anvaya-supabase-anon">
     3. localStorage keys anvaya.supabase.url / anvaya.supabase.anon
     4. (optional) import.meta.env style if a bundler is present

   When no credentials are found the app falls back to the existing
   standalone / Express modes. Offline behaviour is handled by offline.js
   + the outbox, the same way NexTrack queues location points.
   ========================================================================== */
(function (root) {
  'use strict';

  function readMeta(name) {
    const el = document.querySelector(`meta[name="${name}"]`);
    return el && el.content ? el.content.trim() : '';
  }

  function resolveConfig() {
    // 1. Runtime inject (Google AI Studio / host page)
    if (root.__ANVAYA_SUPABASE__ && root.__ANVAYA_SUPABASE__.url && root.__ANVAYA_SUPABASE__.anonKey) {
      return {
        url: root.__ANVAYA_SUPABASE__.url,
        anonKey: root.__ANVAYA_SUPABASE__.anonKey,
        source: 'runtime'
      };
    }

    // 2. Meta tags in index.html
    const metaUrl = readMeta('anvaya-supabase-url');
    const metaAnon = readMeta('anvaya-supabase-anon');
    if (metaUrl && metaAnon) {
      return { url: metaUrl, anonKey: metaAnon, source: 'meta' };
    }

    // 3. localStorage (user can set once from Settings)
    try {
      const url = localStorage.getItem('anvaya.supabase.url');
      const anonKey = localStorage.getItem('anvaya.supabase.anon');
      if (url && anonKey) {
        return { url, anonKey, source: 'localStorage' };
      }
    } catch { /* private mode */ }

    return null;
  }

  let client = null;
  let config = null;

  function getClient() {
    if (client) return client;
    config = resolveConfig();
    if (!config) return null;

    // Prefer the global createClient if the UMD/CDN build or a bundler
    // has already put @supabase/supabase-js on the page.
    const create =
      (root.supabase && root.supabase.createClient) ||
      (root.createClient) ||
      null;

    if (!create) {
      console.warn('[Anvaya] @supabase/supabase-js not loaded. Add the script or use a bundler.');
      return null;
    }

    client = create(config.url, config.anonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true
      }
    });
    return client;
  }

  function isConfigured() {
    return !!resolveConfig();
  }

  function getConfig() {
    return config || resolveConfig();
  }

  // Simple online/offline helpers (same spirit as NexTrack)
  function isOnline() {
    return typeof navigator !== 'undefined' ? navigator.onLine !== false : true;
  }

  root.AnvayaSupabase = {
    getClient,
    isConfigured,
    getConfig,
    isOnline,
    resolveConfig
  };
})(typeof window !== 'undefined' ? window : globalThis);
