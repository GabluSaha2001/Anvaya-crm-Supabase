# Anvaya CRM — Supabase-first + Offline

This build makes **Supabase the primary backend when the device is online**,
and falls back to **local storage / IndexedDB / the built-in engine** when offline
(the same idea used in NexTrack for location queues).

## How it works

```
                 ┌─────────────────────────────┐
                 │         UI (app.js)         │
                 └──────────────┬──────────────┘
                                │
                 AnvayaData.api(path, opts)
                                │
              ┌─────────────────┼─────────────────┐
              │                 │                 │
        ONLINE +            OFFLINE /         STANDALONE
      Supabase set         had server before   never configured
              │                 │                 │
              ▼                 ▼                 ▼
     supabase-js          cache + outbox      engine.js
     (PostgREST + RLS)    (offline.js)      (local demo DB)
```

| State | Source of truth | Writes |
|-------|-----------------|--------|
| **Online + Supabase configured** | Supabase (Postgres + RLS) | Sent immediately via supabase-js / RPC |
| **Offline** (was online before) | Last cached reads | Queued in outbox, replayed on reconnect |
| **Standalone** | engine.js in this browser | Stay local (single-user / demo) |

This matches the NexTrack pattern:

- Detect `navigator.onLine`
- When offline, queue changes (Anvaya already has a proper outbox)
- When back online, sync / replay
- UI shows status chip + pending count

## Configure Supabase (required for online mode)

### Option A — Google AI Studio / host inject (recommended)

In the host page or AI Studio secrets / runtime:

```js
window.__ANVAYA_SUPABASE__ = {
  url: 'https://YOUR_PROJECT.supabase.co',
  anonKey: 'YOUR_ANON_PUBLIC_KEY'
};
```

### Option B — Meta tags in `index.html`

```html
<meta name="anvaya-supabase-url" content="https://YOUR_PROJECT.supabase.co">
<meta name="anvaya-supabase-anon" content="YOUR_ANON_PUBLIC_KEY">
```

### Option C — localStorage (once from Settings / console)

```js
localStorage.setItem('anvaya.supabase.url', 'https://YOUR_PROJECT.supabase.co');
localStorage.setItem('anvaya.supabase.anon', 'YOUR_ANON_PUBLIC_KEY');
```

> The **anon** key is safe to use in the browser. Row Level Security is what
> protects data. Never put the `service_role` key in frontend code.

## Database setup

1. Open your Supabase project → SQL Editor.
2. Paste and run **`supabase/anvaya-supabase.sql`** (or the numbered files in order).
3. Create a user under Authentication → Users (or enable email signup).
4. Re-run the seed section so the workspace attaches to that user.

See also:

- `docs/SUPABASE-LINK.md` — connection string for the optional Express backend
- `docs/SUPABASE-ONLY.md` — path to pure PostgREST + Edge Functions (no Express)
- `supabase/README.md` — schema overview

## Offline behaviour (already built-in)

Anvaya already ships:

- **Cache** of successful GETs (`offline.js`) so screens still open offline
- **Outbox** for mutations made while offline
- **Conflict review** when a queued edit would overwrite a newer server row
- **IndexedDB** helpers (`idb.js`) and a sync engine (`sync.js`)

When Supabase is the online backend, the same outbox is used. On reconnect the
queued operations are replayed (or surfaced for review).

## Optional Express backend

The `backend/` folder remains available if you prefer a Node server that talks
to Supabase over the Postgres protocol (`DATABASE_URL`). For Google AI Studio
and pure browser deployments, prefer the supabase-js path above and leave
`<meta name="anvaya-api">` empty.

## Google AI Studio notes

- Root `package.json` lists `@supabase/supabase-js` so dependency install succeeds.
- The app also loads the UMD build from CDN so it works even without a bundler.
- Set the two Supabase values via Secrets / runtime inject (`window.__ANVAYA_SUPABASE__`).
- Static files at the repo root deploy with zero build step.

## Version

6.8.0 — Supabase-first packaging of Anvaya CRM V6.7
