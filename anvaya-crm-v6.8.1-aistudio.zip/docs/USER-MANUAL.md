# Anvaya CRM — user manual

## Signing in

Open the app URL, enter your work email and password. If your workspace requires
two-factor authentication, the next screen asks for the 6-digit code from your
authenticator app. Lost the phone? Use one of your backup codes — each works once.

## The five things you do every day

1. **Dashboard** — the top card tells you what needs attention: overdue tasks,
   tickets past their deadline, leads nobody has called.
2. **Leads** — someone enquired. Open the lead, log the call, then press
   *Turn into deal*. That creates the contact, the company and the deal at once.
3. **Deals** — drag a card right as it moves forward. Each column is a stage;
   the note under the column header says what that stage means.
4. **Tasks** — tick things off. Overdue items appear on the dashboard.
5. **Customer 360** — everything about one customer: deals, tickets, invoices,
   every call and email, in one timeline.

## Invoices and payments

Create an invoice from **Invoices → Add**. Add line items; the tax and total are
calculated by the server, not by you. Once an invoice exists:

- **PDF** downloads a numbered tax invoice with your company header and GST split.
- **Payment** records money actually received. Part payments are fine; the
  invoice shows *partially paid* until the balance reaches zero.
- **Payments** lists everything received, plus what is overdue and needs chasing.

A refund reduces what the customer has paid. A credit note reduces what they owe.
Both recalculate the invoice immediately.

## Asking the copilot

Press **Ask Anvaya** in the header. It answers from your records only, and tells
you which rule it used. When it suggests a change, it waits for your approval
before doing anything.

## Installing on your phone or laptop

Windows and macOS: use the install icon in the browser address bar.
Android: menu → *Install app*.
iOS: must be Safari → Share → *Add to Home Screen*.

## If something looks wrong

Reload once. If a figure looks wrong, open the record and check the payments or
line items — totals are always recalculated from those, never typed by hand.
