# Can Supabase replace the Anvaya backend completely?

**Yes — with one honest qualifier: four jobs cannot run inside a database, so
they move into Supabase Edge Functions.** The result is still one system to
manage: one project, one bill, one place to deploy. What disappears is the
separate Express server you have to host, patch and monitor.

---

## What moves where

| Today (Express) | Supabase equivalent | Status |
|---|---|---|
| Password auth, cookie sessions | **Supabase Auth** (GoTrue) — JWT, refresh, password reset | Replaces it |
| MFA (TOTP + backup codes) | **Supabase Auth MFA** — TOTP and recovery codes built in | Replaces it |
| `/api/leads`, `/api/deals`, … (16 resources) | **PostgREST**: `supabase.from('leads').select()` — RLS enforces tenancy | Replaces it |
| Lead → contact → deal conversion | `app.convert_lead(uuid)` | **Built and tested** |
| Invoice totals, tax, numbering | `app.create_invoice(...)`, `app.next_number(text)` | **Built and tested** |
| Invoice balance after a payment | `app.recalculate_invoice(uuid)` | **Built and tested** |
| Dashboard aggregates (six queries) | `app.dashboard()` — one round trip | **Built and tested** |
| Search across five tables | `app.search(text)` RPC | To build, ~1 hour |
| Public web forms | RPC granted to `anon`, with the same honeypot + rate limit in SQL | To build, ~2 hours |
| PDF quotations, invoices, receipts | **Edge Function** (Deno + pdf-lib) | Cannot run in Postgres |
| Outbound webhooks, retries | **Edge Function** + `pg_cron` | Cannot run in Postgres |
| Payment gateway webhooks (signature check) | **Edge Function** | Cannot run in Postgres |
| Copilot with a model API key | **Edge Function** (the key must not reach the browser) | Cannot run in Postgres |
| Per-tenant API keys for Zapier | RLS cannot express per-key scopes; either Edge Function or PostgREST + one row per key | Partly |

So: **database work → Postgres functions. Everything else → PostgREST.
Four things → Edge Functions.** No Express.

---

## What is already done

`supabase/05_functions.sql` (also folded into `anvaya-supabase.sql`) contains
five functions, verified by calling them the way PostgREST would — as the
`authenticated` role with a JWT claim, so row-level security applies inside
them:

```
convert_lead    → deal, company, contact created; lead marked converted
create_invoice  → INV-2026-0001, subtotal 10,000, tax 1,620, total 10,620
recalculate_invoice after a 4,000 payment → outstanding 6,620, partially_paid
dashboard       → open deals, pipeline value, leads, outstanding in one call
```

They are `SECURITY INVOKER`, not `SECURITY DEFINER`. That is deliberate: the
caller's JWT decides what they can touch, and there is no privileged path that
could leak another organisation's rows.

---

## What the switch actually costs

| Piece | Effort | Risk |
|---|---|---|
| Frontend data layer: `/api/...` → `supabase.from(...)` and `.rpc(...)` | 2–3 days | Medium — every screen touched, but the shapes stay the same |
| Auth screens → `supabase.auth` | half a day | Low |
| Four Edge Functions | 2 days | Medium — Deno, new deployment target |
| Removing Express, updating docs | half a day | Low |

**The blocker on my side:** I cannot test the browser-to-Supabase path from this
environment — the sandbox network refuses your project host, and there is no
local PostgREST to point at. Everything in the database I can prove here, and
have. The client-side half would be shipped unverified, which is exactly what
you told me not to do.

---

## The recommended sequence

1. **Now**: keep the Express backend, point it at Supabase with `DATABASE_URL`.
   This works today, is tested, and gets your data into Supabase. One evening.
2. **Next**: build `app.search()` and the web-form RPC. Both are small, both are
   testable here, and both remove endpoints from the server.
3. **Then**: write the frontend data layer against those RPCs *alongside* the
   existing one, switched by a flag, so you can compare screen by screen before
   removing anything.
4. **Finally**: the four Edge Functions, then delete Express.

Doing step 3 before 1 leaves you with two sources of truth and no working app,
which is the one outcome worth avoiding.

---

## If you want one command instead of four steps

The alternative to all of the above is a **setup wizard** inside the app: on
first boot, a screen asks for the Supabase connection string, tests it, applies
the schema, and writes the config. Same end state as step 1, no hand-editing of
`.env`, and your own customers could onboard themselves. Say the word and I will
build it — it is a day, and it is testable here because it runs locally.
